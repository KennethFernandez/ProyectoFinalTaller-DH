/************************************************************************/
/*																		*/
/*	ADCSPI.h	--	Declaration for ADCSPI library 	    				*/
/*																		*/
/************************************************************************/
/*	Author:		Cristian Fatu											*/
/*	Copyright 2012, Digilent Inc.										*/
/************************************************************************/
/*  File Description:													*/
/*	This file declares the ADCSPI library functions and the constants	*/
/*	involved.															*/
/*																		*/
/************************************************************************/
/*  Revision History:													*/
/*																		*/
/*	01/10/2012(CristianF): created										*/
/*  06/19/2012(MichaelK) : Changed floating point calculations to       */
/*                        conditional compilation						*/
/*																		*/
/************************************************************************/
#if !defined(ADCSPI_H)
#define ADCSPI_H

#define AD1_FLOATING_POINT

/* ------------------------------------------------------------ */
/*				Include File Definitions						*/
/* ------------------------------------------------------------ */
#include <inttypes.h>
#include <DSPI.h>

/* ------------------------------------------------------------ */
/*					Definitions									*/
/* ------------------------------------------------------------ */
#define ADCSPI_NO_BITS		12

#define ADCSPI_SPI_FREQ	1000000 // 1 MHz - default spi freq
#define	PAR_ACCESS_SPI0			0
#define	PAR_ACCESS_SPI1			1
#define	PAR_ACCESS_I2C			2	
/* ------------------------------------------------------------ */
/*					Procedure Declarations						*/
/* ------------------------------------------------------------ */


class ADCSPI {
private: 
	DSPI *pdspi;
	uint8_t m_SSPin;

public:
	uint16_t GetIntegerValue();

#ifdef AD1_FLOATING_POINT
	float GetPhysicalValue(float dReference = 3.3);
#endif

	ADCSPI();
	void begin(uint8_t bAccessType);
};



#endif
